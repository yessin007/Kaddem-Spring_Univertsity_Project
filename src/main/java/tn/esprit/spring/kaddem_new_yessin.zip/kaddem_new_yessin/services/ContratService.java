package tn.esprit.spring.kaddem_new_yessin.services;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tn.esprit.spring.kaddem_new_yessin.entities.*;
import tn.esprit.spring.kaddem_new_yessin.repository.*;

import java.util.List;

@Service
@Slf4j

public class ContratService implements InterfaceContratService{
    @Autowired

    ContratRepository contratRepository;

    @Override
    public List<Contrat> retrieveAllcontrats() {

        return contratRepository.findAll();
    }

    @Override
    public Contrat retrieveContrat(Long idContart) {
        return contratRepository.findById(idContart).get();
    }

    @Override
    public Contrat addContrat(Contrat c) {
        return contratRepository.save(c);
    }

    @Override
    public void deleteContrat(Long idContrat) {

        contratRepository.deleteById(idContrat);
    }

    @Override
    public Contrat updateContrat(Contrat c) {

        return contratRepository.save(c);
    }
}
