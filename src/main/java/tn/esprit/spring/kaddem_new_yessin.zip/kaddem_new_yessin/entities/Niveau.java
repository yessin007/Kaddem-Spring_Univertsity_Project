package tn.esprit.spring.kaddem_new_yessin.entities;

public enum Niveau {
    JUNIOR,SENIOR,EXPERT
}
