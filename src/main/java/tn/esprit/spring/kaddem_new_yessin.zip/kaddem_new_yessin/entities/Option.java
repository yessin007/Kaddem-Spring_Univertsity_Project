package tn.esprit.spring.kaddem_new_yessin.entities;

public enum Option {
    GAMIX,SE,SIM,NIDS
}
