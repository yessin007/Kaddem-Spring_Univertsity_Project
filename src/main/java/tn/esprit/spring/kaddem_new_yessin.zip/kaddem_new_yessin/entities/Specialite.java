package tn.esprit.spring.kaddem_new_yessin.entities;

public enum Specialite {
    IA,RESEAUX,CLOUD,SECURITE
}
